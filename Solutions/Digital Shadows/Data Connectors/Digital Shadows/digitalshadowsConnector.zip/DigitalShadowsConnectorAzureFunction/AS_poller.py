""" polls data from Microsoft Sentinel incidents to DS """

class poller:
    pass